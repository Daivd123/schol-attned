import * as React from 'react';
import {Text, View, StyleSheet} from 'react-native';
import db from '../config';


class Summaryscreen extends React.Component{
  constructor() {
    super() {
      this.state = {
        name:[],
        present_students: [],
        absent_students:[],
      };
    }
  }
}